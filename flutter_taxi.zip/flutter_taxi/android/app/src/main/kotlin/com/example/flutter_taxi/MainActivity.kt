package com.example.flutter_taxi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
